from paddleocr import PaddleOCR

ocr = PaddleOCR(
    use_angle_cls=True,
    lang='en'
)


def run_ocr(image_path):

    result = ocr.ocr(image_path)

    extracted_text = ""

    for line in result[0]:

        text = line[1][0]
        confidence = line[1][1]

        extracted_text += (
            f"Text: {text} | "
            f"Confidence: {confidence}\n"
        )

    return extracted_text