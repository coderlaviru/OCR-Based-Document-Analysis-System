import os


def save_text(text, filename="output.txt"):

    output_path = os.path.join(
        "outputs",
        filename
    )

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(text)

    return output_path